const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const rooms = new Map();
const CHARACTERS = [
  { id: "birbikrom", name: "বীরবিক্রম", power: "ব্যাংক থেকে ৩টি কয়েন নিতে পারে" },
  { id: "brahmadotto", name: "ব্রহ্মদত্ব", power: "৩টি কয়েন লক্ষ্য খেলোয়াড়কে দিয়ে তার ১টি জীবন কমাতে পারে; অন্য ব্রহ্মদত্বের আক্রমণ ব্লক করতে পারে" },
  { id: "petukchandra", name: "পেটুকচন্দ্র", power: "Hidden Deck থেকে ২টি কার্ড নিয়ে নিজের কার্ড বদলায়; পুরোনো কার্ড ডেকের নিচে ফেরত দেয়" },
  { id: "kalo_dakat", name: "কালো ডাকাত", power: "একজনের কাছ থেকে ২টি কয়েন চুরি করে; চুরি ব্লক করতে পারে" },
  { id: "chichke_chor", name: "ছিঁচকে চোর", power: "বাকি প্রত্যেক খেলোয়াড়ের কাছ থেকে ১টি করে কয়েন চুরি করে; চুরি ব্লক করতে পারে" }
];
const cardCopies = () => CHARACTERS.flatMap(c => [0,1,2,3].map(n => ({...c, serial: `${c.id}-${n}-${Math.random().toString(36).slice(2,7)}`})));
const shuffle = a => { for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return a; };
const code = () => Math.random().toString(36).slice(2,6).toUpperCase();
const alive = p => p && p.lives.length > 0;
function roomPublic(room) {
  const players = room.players.map(p => ({
    id:p.id, name:p.name, coins:p.coins, livesCount:p.lives.length,
    lives: p.id === room.currentViewer ? p.lives.map(c => ({id:c.id,name:c.name,serial:c.serial})) : [],
    connected:p.connected
  }));
  return {
    code:room.code, players, started:room.started, currentPlayerId:room.currentPlayerId,
    pending: room.pending ? {actorId:room.pending.actorId, actorName:room.players.find(p=>p.id===room.pending.actorId)?.name,
      characterId:room.pending.characterId, characterName:CHARACTERS.find(c=>c.id===room.pending.characterId)?.name,
      action:room.pending.action, targetId:room.pending.targetId, targetName:room.players.find(p=>p.id===room.pending.targetId)?.name,
      eligibleChallengers:room.pending.eligibleChallengers} : null,
    log:room.log.slice(-12), winnerId:room.winnerId,
    characterList:CHARACTERS
  };
}
function emitRoom(room) {
  for (const p of room.players) {
    room.currentViewer = p.id;
    io.to(p.id).emit("state", roomPublic(room));
  }
  delete room.currentViewer;
}
function log(room, msg) { room.log.push(msg); if(room.log.length>40) room.log.shift(); }
function nextTurn(room) {
  room.pending = null;
  if (room.players.filter(alive).length <= 1) {
    room.winnerId = room.players.find(alive)?.id || null;
    room.started = false;
    log(room, room.winnerId ? `🏆 ${room.players.find(p=>p.id===room.winnerId).name} জয়ী হয়েছে!` : "খেলা শেষ।");
    return;
  }
  const living = room.players.filter(alive);
  let idx = room.players.findIndex(p=>p.id===room.currentPlayerId);
  for(let i=1;i<=room.players.length;i++){
    const p=room.players[(idx+i)%room.players.length];
    if(alive(p)){ room.currentPlayerId=p.id; break; }
  }
}
function loseLife(room, player, reason) {
  if (!alive(player)) return;
  const lost = player.lives.shift();
  log(room, `${player.name} ১টি জীবন হারিয়েছে (${reason})।`);
  if(player.lives.length===0) log(room, `${player.name} খেলায় বাদ পড়েছে।`);
  return lost;
}
function refillDeck(room) {
  if(room.deck.length < 2) room.deck.push(...shuffle(cardCopies()));
}
function draw(room) { refillDeck(room); return room.deck.shift(); }
function finishAction(room, actorId) {
  if(room.pending && room.pending.actorId===actorId) room.pending=null;
  nextTurn(room);
  emitRoom(room);
}
function activeRoom(socket) {
  const code = socket.data.roomCode;
  const room = rooms.get(code);
  if(!room) throw new Error("রুম পাওয়া যায়নি।");
  const p = room.players.find(x=>x.id===socket.id);
  if(!p) throw new Error("তুমি এই রুমে নেই।");
  return {room,p};
}
function err(socket, message){socket.emit("notice", {type:"error", message});}
function startRoom(room) {
  if(room.players.length<2) throw new Error("খেলা শুরু করতে অন্তত ২ জন খেলোয়াড় লাগবে।");
  room.deck=shuffle(cardCopies());
  room.players.forEach(p=>{p.coins=2;p.lives=[draw(room),draw(room)];});
  room.started=true; room.pending=null; room.winnerId=null;
  room.currentPlayerId=room.players[0].id;
  room.log=[];
  log(room, "খেলা শুরু! প্রত্যেক খেলোয়াড় ২টি কয়েন ও ২টি Character Card পেয়েছে।");
}
io.on("connection", socket => {
  socket.on("createRoom", ({name}) => {
    try {
      const playerName=String(name||"খেলোয়াড়").trim().slice(0,18) || "খেলোয়াড়";
      let roomCode; do { roomCode=code(); } while(rooms.has(roomCode));
      const room={code:roomCode,players:[{id:socket.id,name:playerName,coins:2,lives:[],connected:true}],started:false,deck:[],currentPlayerId:null,pending:null,log:[],winnerId:null};
      rooms.set(roomCode,room); socket.data.roomCode=roomCode; socket.join(roomCode);
      log(room, `${playerName} রুম তৈরি করেছে।`);
      emitRoom(room); socket.emit("joined", {code:roomCode, playerId:socket.id});
    } catch(e){err(socket,e.message);}
  });
  socket.on("joinRoom", ({name,code:rawCode}) => {
    const roomCode=String(rawCode||"").trim().toUpperCase();
    const room=rooms.get(roomCode);
    if(!room) return err(socket,"এই Room Code পাওয়া যায়নি।");
    if(room.started) return err(socket,"খেলা শুরু হয়ে গেছে; নতুন খেলোয়াড় যোগ দিতে পারবে না।");
    if(room.players.length>=6) return err(socket,"একটি রুমে সর্বোচ্চ ৬ জন খেলতে পারবে।");
    const playerName=String(name||"খেলোয়াড়").trim().slice(0,18) || "খেলোয়াড়";
    room.players.push({id:socket.id,name:playerName,coins:2,lives:[],connected:true});
    socket.data.roomCode=roomCode; socket.join(roomCode);
    log(room, `${playerName} যোগ দিয়েছে।`);
    emitRoom(room); socket.emit("joined",{code:roomCode,playerId:socket.id});
  });
  socket.on("startGame", () => {
    try { const {room,p}=activeRoom(socket); if(room.players[0].id!==p.id) return err(socket,"শুধু রুম তৈরি করা খেলোয়াড় খেলা শুরু করতে পারবে।"); if(room.started) return err(socket,"খেলা ইতিমধ্যে শুরু হয়েছে।"); startRoom(room); emitRoom(room); }
    catch(e){err(socket,e.message);}
  });
  socket.on("takeCoin", () => {
    try { const {room,p}=activeRoom(socket); if(!room.started||room.currentPlayerId!==p.id||room.pending) return err(socket,"এখন তোমার পালা নয়।"); p.coins+=1; log(room,`${p.name} ব্যাংক থেকে ১টি কয়েন নিয়েছে।`); finishAction(room,p.id); }
    catch(e){err(socket,e.message);}
  });
  socket.on("claimPower", ({characterId,targetId,exchangeSerials}) => {
    try {
      const {room,p}=activeRoom(socket);
      if(!room.started||room.currentPlayerId!==p.id||room.pending) return err(socket,"এখন তোমার পালা নয়।");
      const c=CHARACTERS.find(x=>x.id===characterId); if(!c) return err(socket,"চরিত্রটি পাওয়া যায়নি।");
      const target=room.players.find(x=>x.id===targetId);
      const action = characterId==="birbikrom"?"bank3":characterId==="brahmadotto"?"attack":characterId==="petukchandra"?"exchange":characterId==="kalo_dakat"?"steal2":"stealAll";
      if(["attack","steal2"].includes(action) && (!alive(target)||target.id===p.id)) return err(socket,"একজন জীবিত অন্য খেলোয়াড় নির্বাচন করো।");
      if(action==="attack" && p.coins<3) return err(socket,"এই পাওয়ার ব্যবহার করতে ৩টি কয়েন দরকার।");
      if(action==="steal2" && target.coins<1) return err(socket,"লক্ষ্য খেলোয়াড়ের কাছে চুরি করার মতো কয়েন নেই।");
      if(action==="stealAll" && room.players.filter(x=>alive(x)&&x.id!==p.id&&x.coins>0).length===0) return err(socket,"অন্য কারও কাছে কয়েন নেই।");
      const eligible=room.players.filter(x=>alive(x)&&x.id!==p.id).map(x=>x.id);
      room.pending={actorId:p.id,characterId,action,targetId:target?.id||null,eligibleChallengers:eligible,exchangeSerials:Array.isArray(exchangeSerials)?exchangeSerials:[]};
      log(room,`${p.name} ${c.name}-এর পাওয়ার ব্যবহার করার দাবি করেছে। অন্যরা Challenge করতে পারো।`);
      emitRoom(room);
    } catch(e){err(socket,e.message);}
  });
  socket.on("eliminate", ({targetId}) => {
    try {
      const {room,p}=activeRoom(socket); if(!room.started||room.currentPlayerId!==p.id||room.pending) return err(socket,"এখন তোমার পালা নয়।");
      const target=room.players.find(x=>x.id===targetId);
      if(!alive(target)||target.id===p.id) return err(socket,"একজন জীবিত অন্য খেলোয়াড় নির্বাচন করো।");
      if(p.coins<7) return err(socket,"খেলোয়াড়কে বাদ দিতে ৭টি কয়েন লাগবে।");
      p.coins-=7; loseLife(room,target,"৭ কয়েন দিয়ে বাদ দেওয়ার আক্রমণ");
      log(room,`${p.name} ব্যাংকে ৭টি কয়েন দিয়ে ${target.name}-কে আক্রমণ করেছে।`);
      nextTurn(room); emitRoom(room);
    } catch(e){err(socket,e.message);}
  });
  socket.on("challenge", () => {
    try {
      const {room,p}=activeRoom(socket); const pend=room.pending;
      if(!pend) return err(socket,"Challenge করার মতো কোনো দাবি নেই।");
      if(p.id===pend.actorId||!alive(p)||!pend.eligibleChallengers.includes(p.id)) return err(socket,"তুমি এই দাবিকে Challenge করতে পারবে না.");
      const actor=room.players.find(x=>x.id===pend.actorId);
      const claimed=CHARACTERS.find(c=>c.id===pend.characterId);
      const has=actor.lives.findIndex(c=>c.id===pend.characterId);
      if(has<0){
        loseLife(room,actor,"ভুয়া দাবি");
        log(room,`${actor.name} ${claimed.name} দাবি করেছিল, কিন্তু তার কাছে কার্ডটি ছিল না।`);
      } else {
        loseLife(room,p,"সঠিক দাবি Challenge করার শাস্তি");
        const idx=actor.lives.findIndex(c=>c.id===pend.characterId);
        if(idx>=0){const old=actor.lives.splice(idx,1)[0]; room.deck.push(old); actor.lives.push(draw(room));}
        log(room,`${actor.name} সত্য বলেছিল। ${claimed.name} কার্ড বদলে Hidden Deck থেকে নতুন কার্ড নিয়েছে।`);
      }
      const actorId=pend.actorId;
      room.pending=null;
      nextTurn(room);
      emitRoom(room);
    } catch(e){err(socket,e.message);}
  });
  socket.on("resolvePower", ({accept,blockerCharacterId}) => {
    try {
      const {room,p}=activeRoom(socket); const pend=room.pending;
      if(!pend||pend.actorId!==p.id) return err(socket,"তোমার কোনো পাওয়ার অপেক্ষায় নেই।");
      if(accept===false) { room.pending=null; log(room,`${p.name}-এর পাওয়ার বাতিল করা হয়েছে।`); nextTurn(room); emitRoom(room); return; }
      const target=room.players.find(x=>x.id===pend.targetId);
      if(pend.action==="bank3"){p.coins+=3;log(room,`${p.name} বীরবিক্রমের পাওয়ারে ব্যাংক থেকে ৩টি কয়েন নিয়েছে।`);}
      if(pend.action==="attack"){
        if(!alive(target)) return err(socket,"লক্ষ্য খেলোয়াড় আর খেলায় নেই।");
        if(target.lives.some(c=>c.id==="brahmadotto")){log(room,`${target.name}-এর ব্রহ্মদত্ব আক্রমণ ব্লক করেছে।`);}
        else if(p.coins<3){log(room,`${p.name}-এর কাছে আর ৩টি কয়েন নেই; আক্রমণ ব্যর্থ।`);}
        else {p.coins-=3;target.coins+=3;loseLife(room,target,"ব্রহ্মদত্বের আক্রমণ");log(room,`${p.name} ৩টি কয়েন ${target.name}-কে দিয়েছে।`);}
      }
      if(pend.action==="steal2"){
        if(!alive(target)||target.coins<1) log(room,"চুরি করা যায়নি।");
        else if(target.lives.some(c=>["kalo_dakat","chichke_chor"].includes(c.id))) log(room,`${target.name} চুরি ব্লক করেছে।`);
        else {const n=Math.min(2,target.coins);target.coins-=n;p.coins+=n;log(room,`${p.name}, ${target.name}-এর কাছ থেকে ${n}টি কয়েন চুরি করেছে।`);}
      }
      if(pend.action==="stealAll"){
        let stolen=0;
        for(const t of room.players){if(alive(t)&&t.id!==p.id&&t.coins>0){if(t.lives.some(c=>["kalo_dakat","chichke_chor"].includes(c.id))){log(room,`${t.name} চুরি ব্লক করেছে।`);}else{t.coins--;p.coins++;stolen++;}}}
        log(room,`${p.name} মোট ${stolen}টি কয়েন চুরি করেছে।`);
      }
      if(pend.action==="exchange"){
        const current=p.lives.slice();
        const drawn=[draw(room),draw(room)];
        // Prototype lets player choose which two cards to keep from the four, using selected own card serials.
        const selected=new Set(pend.exchangeSerials||[]);
        const keep=current.filter(c=>!selected.has(c.serial));
        const old=current.filter(c=>selected.has(c.serial));
        // Default exchange the first two if no valid selection
        let finalKeep=keep;
        if(old.length===0){old.push(...current.slice(0,Math.min(2,current.length)));finalKeep=current.slice(old.length);}
        const pool=[...finalKeep,...drawn];
        while(pool.length<2) pool.push(draw(room));
        p.lives=pool.slice(0,2);
        old.forEach(c=>room.deck.push(c));
        log(room,`${p.name} পেটুকচন্দ্রের পাওয়ারে কার্ড বদল করেছে; পুরোনো কার্ড ডেকের নিচে ফেরত গেছে।`);
      }
      room.pending=null; nextTurn(room); emitRoom(room);
    } catch(e){err(socket,e.message);}
  });
  socket.on("disconnect", () => {
    const code=socket.data.roomCode; const room=rooms.get(code); if(!room)return;
    const p=room.players.find(x=>x.id===socket.id); if(p){p.connected=false;log(room,`${p.name} সংযোগ হারিয়েছে।`);}
    if(room.players.every(x=>!x.connected)) rooms.delete(code); else emitRoom(room);
  });
});
server.listen(PORT,()=>console.log(`ষড়যন্ত্র server listening on ${PORT}`));
