# ষড়যন্ত্র — Online Multiplayer Browser Prototype

## Run on your computer
1. Install Node.js 18 or newer.
2. Extract this folder.
3. In this folder run: `npm install`
4. Run: `npm start`
5. Open `http://localhost:3000`.

## Play from different phones
The server must be deployed to a public Node.js hosting service. After deployment, open the public URL on each phone. One player creates a room and shares the 4-character Room Code; the others enter it to join.

This ZIP is source code, not a hosted public website. It does not become accessible on the internet until you deploy it.

## Prototype rules included
- 2–6 players, 2 coins and 2 character cards per player.
- Take 1 coin, claim a character power, or pay 7 coins to attack a selected player (removes one life card).
- Other players can challenge a claimed character power.
- Five agreed characters and basic powers are included.
- The game is a prototype: card-exchange choices, block timing and full rule edge cases need more testing/refinement before treating it as a final game.
