const socket = io();
const $ = id => document.getElementById(id);
let state = null, myId = null, roomCode = null, selectedExchange = new Set();
const names = {birbikrom:"বীরবিক্রম",brahmadotto:"ব্রহ্মদত্ব",petukchandra:"পেটুকচন্দ্র",kalo_dakat:"কালো ডাকাত",chichke_chor:"ছিঁচকে চোর"};
const powers = {
 birbikrom:"ব্যাংক থেকে ৩টি কয়েন নিতে পারে",
 brahmadotto:"৩টি কয়েন লক্ষ্য খেলোয়াড়কে দিয়ে তার ১টি জীবন কমাতে পারে",
 petukchandra:"২টি কার্ড তুলে নিজের কার্ড বদলায়",
 kalo_dakat:"একজনের কাছ থেকে ২টি কয়েন চুরি করে",
 chichke_chor:"বাকি সবার কাছ থেকে ১টি করে কয়েন চুরি করে"
};
const emojis={birbikrom:"🛡️",brahmadotto:"⚔️",petukchandra:"🍲",kalo_dakat:"🦹",chichke_chor:"🪙"};
function show(el,yes=true){$(el).classList.toggle("hidden",!yes)}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function notify(message){$("notice").textContent=message;show("notice");setTimeout(()=>show("notice",false),4500)}
function me(){return state?.players.find(p=>p.id===myId)}
function activePlayers(excludeSelf=true){return (state?.players||[]).filter(p=>p.livesCount>0&&(!excludeSelf||p.id!==myId))}
function fillTargets(id, excludeSelf=true){
 const select=$(id), prev=select.value; select.innerHTML="";
 activePlayers(excludeSelf).forEach(p=>{const o=document.createElement("option");o.value=p.id;o.textContent=`${p.name} · ${p.coins} 🪙`;select.appendChild(o)});
 if([...select.options].some(o=>o.value===prev))select.value=prev;
}
function renderPlayers(targetId){
 $(targetId).innerHTML=state.players.map(p=>`<div class="player-card ${p.id===state.currentPlayerId?'current':''} ${p.livesCount===0?'out':''}">
 <div class="player-name">${escapeHtml(p.name)} ${p.id===myId?'<span class="you">তুমি</span>':''}</div>
 <div class="player-meta"><span>🪙 ${p.coins}</span><span>❤️ ${p.livesCount}/2</span><span>${p.connected?'● যুক্ত':'○ সংযোগ নেই'}</span></div>
 </div>`).join("");
}
function renderCards(){
 const p=me(); if(!p)return;
 $("myCards").innerHTML=p.lives.map(c=>`<div class="character-card"><div class="emoji">${emojis[c.id]||"🎭"}</div><strong>${escapeHtml(c.name)}</strong><p>${escapeHtml(powers[c.id]||"বিশেষ ক্ষমতা")}</p></div>`).join("");
}
function render(){
 if(!state)return;
 show("lobby",false);show("game");
 $("roomCodeView").textContent=state.code;
 const host=state.players[0]?.id===myId;
 show("waitingPanel",!state.started && !state.winnerId);
 show("boardPanel",state.started);
 $("startBtn").disabled=!host||state.players.length<2;
 $("startBtn").textContent=host?"▶ খেলা শুরু":"রুম তৈরি করা খেলোয়াড়ের অপেক্ষায়…";
 renderPlayers("waitingPlayers");renderPlayers("playersBoard");renderCards();
 const current=state.players.find(p=>p.id===state.currentPlayerId);
 $("turnBadge").textContent=state.started?(current?`পালা: ${current.name}`:"খেলা শেষ"):"খেলা শুরু হয়নি";
 const isMyTurn=state.started&&state.currentPlayerId===myId&&!state.pending;
 $("takeBtn").disabled=!isMyTurn;
 $("powerBtn").disabled=!isMyTurn;
 $("eliminateBtn").disabled=!isMyTurn;
 show("actionPanel",state.started&&!state.winnerId);
 show("powerForm",false);show("eliminateForm",false);
 const pend=state.pending;
 show("pendingPanel",!!pend&&pend.actorId!==myId&&pend.eligibleChallengers.includes(myId));
 show("resolvePanel",!!pend&&pend.actorId===myId);
 if(pend){
   $("pendingTitle").textContent=`${pend.actorName} ${pend.characterName}-এর পাওয়ার দাবি করেছে`;
   $("pendingText").textContent=`তুমি চাইলে দাবিটিকে Challenge করতে পারো।`;
   $("resolveText").textContent=`কেউ Challenge না করলে ${pend.characterName}-এর পাওয়ার সম্পন্ন করো।`;
 }
 const characterSelect=$("powerCharacter");characterSelect.innerHTML="";
 state.characterList.forEach(c=>{const o=document.createElement("option");o.value=c.id;o.textContent=`${c.name} — ${c.power}`;characterSelect.appendChild(o)});
 fillTargets("powerTarget");fillTargets("eliminateTarget");
 const targetNeeded=["brahmadotto","kalo_dakat"].includes(characterSelect.value);
 show("targetWrap",targetNeeded);
 $("gameLog").innerHTML=state.log.slice().reverse().map(line=>`<div class="log-item">${escapeHtml(line)}</div>`).join("");
 show("winnerPanel",!!state.winnerId);
 if(state.winnerId){const w=state.players.find(p=>p.id===state.winnerId);$("winnerText").innerHTML=`<span class="winner">${escapeHtml(w?.name||"একজন খেলোয়াড়")}</span> জয়ী হয়েছে!`;show("actionPanel",false);show("waitingPanel",false);}
}
$("createBtn").onclick=()=>{socket.emit("createRoom",{name:$("playerName").value})};
$("joinBtn").onclick=()=>{socket.emit("joinRoom",{name:$("playerName").value,code:$("roomCode").value})};
$("roomCode").addEventListener("input",e=>e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,""));
$("startBtn").onclick=()=>socket.emit("startGame");
$("copyBtn").onclick=async()=>{try{await navigator.clipboard.writeText(roomCode||state?.code);notify("Room Code কপি হয়েছে!");}catch(e){notify("Room Code: "+(roomCode||state?.code));}};
$("takeBtn").onclick=()=>socket.emit("takeCoin");
$("powerBtn").onclick=()=>{show("powerForm");show("eliminateForm",false);};
$("eliminateBtn").onclick=()=>{show("eliminateForm");show("powerForm",false);};
$("powerCharacter").onchange=()=>show("targetWrap",["brahmadotto","kalo_dakat"].includes($("powerCharacter").value));
$("claimBtn").onclick=()=>socket.emit("claimPower",{characterId:$("powerCharacter").value,targetId:$("powerTarget").value});
$("confirmEliminateBtn").onclick=()=>socket.emit("eliminate",{targetId:$("eliminateTarget").value});
$("challengeBtn").onclick=()=>socket.emit("challenge");
$("resolveBtn").onclick=()=>socket.emit("resolvePower",{accept:true,exchangeSerials:[...selectedExchange]});
$("cancelPowerBtn").onclick=()=>socket.emit("resolvePower",{accept:false});
$("reloadBtn").onclick=()=>location.reload();
socket.on("joined",d=>{roomCode=d.code;myId=d.playerId;$("lobbyError").textContent="";notify("রুমে ঢুকেছ! বন্ধুদের Room Code পাঠাও: "+d.code);});
socket.on("state",s=>{state=s;render();});
socket.on("notice",d=>{if(d.type==="error"){$("lobbyError").textContent=d.message;notify(d.message)}});
socket.on("connect_error",()=>notify("সার্ভারে সংযোগ হচ্ছে না। একটু পরে চেষ্টা করো।"));
